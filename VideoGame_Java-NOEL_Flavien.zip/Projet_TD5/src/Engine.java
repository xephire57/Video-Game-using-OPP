//Peut-on instancier une interface ? Non. On peut pas faire de new Engine();. C une structure abstraite qui sert qu'à définir un comportement.
//À quelle condition une classe peut-elle implémenter l'interface Engine ? Elle doit obligatoirement fournir le code de la méthode définie dans l'interface. Donc il faut qu'elle contienne un bloc public void update() { ... }
//Une classe peut-elle implémenter plusieurs interfaces ? Oui

public interface Engine {
    public void update();
}
