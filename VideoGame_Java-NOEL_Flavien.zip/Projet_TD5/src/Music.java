import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

public class Music {
    private Clip clip;

    public void playBackgroundMusic(String filePath) {
        try {
            File musicPath = new File(filePath);

            if (musicPath.exists()) {
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(musicPath);
                clip = AudioSystem.getClip();
                clip.open(audioInput);

                clip.start();

                clip.loop(Clip.LOOP_CONTINUOUSLY);

            }
        }
        catch (Exception e) {
            System.out.println("erreur");
            e.printStackTrace();
        }
    }

    public void playSound(String filePath) {
        try {
            File soundPath = new File(filePath);

            if (soundPath.exists()) {
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(soundPath);
                Clip sound = AudioSystem.getClip();
                sound.open(audioInput);
                sound.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopMusic() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }
}