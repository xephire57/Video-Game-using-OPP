import java.util.ArrayList;

public class PhysicEngine implements Engine {
    private ArrayList<DynamicSprite> movingSpiteList;
    private ArrayList<Sprite> environment;

    public PhysicEngine() {
        this.movingSpiteList = new ArrayList<>();
    }

    public void addToMovingSpriteList(DynamicSprite s){
        this.movingSpiteList.add(s);
    }

    public void setEnvironment(ArrayList<Sprite> environment) {
        this.environment = environment;
    }


    @Override
    public void update() {
        for (DynamicSprite d : movingSpiteList){
            d.moveIfPossible(environment);
        }
    }
}
