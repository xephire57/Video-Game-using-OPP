import javax.swing.*;
import java.awt.*;

public class Health extends JPanel {
    private final JLabel[] hearts = new JLabel[3];
    private final ImageIcon fullHeart;
    private final ImageIcon emptyHeart;

    public Health() {
        this.setOpaque(false);
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        fullHeart = new ImageIcon("./img/heart2.png");
        emptyHeart = new ImageIcon("./img/heartbreak2.png");

        for (int i = 0; i < 3; i++) {
            hearts[i] = new JLabel(fullHeart);
            this.add(hearts[i]);
        }
    }

    public void updateHealth(int currentHealth) {
        for (int i = 0; i < 3; i++) {
            if (i < currentHealth) {
                hearts[i].setIcon(fullHeart);
            }
            else {
                hearts[i].setIcon(emptyHeart);
            }
        }

        this.repaint();
    }
}