public enum Direction {
    NORTH(2),EAST(3),SOUTH(0),WEST(1);
    private int frameLineNumber;

    Direction(int i) {
        this.frameLineNumber = i;
    }

    public int getFrameLineNumber() {
        return this.frameLineNumber;
    }
}
