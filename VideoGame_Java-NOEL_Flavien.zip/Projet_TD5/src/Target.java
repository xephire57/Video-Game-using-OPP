import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Target extends SolidSprite {

    public Target(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }

    public void respawn(ArrayList<Sprite> environment) {
        boolean isPositionValid = false;
        double newX = 0;
        double newY = 0;
        Rectangle2D.Double testHitBox;

        while (!isPositionValid) {
            isPositionValid = true;
            newX = 64 + (Math.random() * 636);
            newY = 64 + (Math.random() * 636);

            testHitBox = new Rectangle2D.Double(newX, newY, this.width, this.height);

            // vérification de la présence d'un obstacle
            for (Sprite s : environment) {
                if (s.isSolidSprite() && s != this) {
                    Rectangle2D.Double obstacle = new Rectangle2D.Double(s.x, s.y, s.width, s.height);
                    if (testHitBox.intersects(obstacle)) {
                        isPositionValid = false;
                        break;
                    }
                }
            }
        }

        this.x = newX;
        this.y = newY;
    }

    @Override
    public boolean isTarget() {
        return true;
    }
}