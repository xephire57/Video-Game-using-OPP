import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class RenderEngine extends JPanel implements Engine {
    private ArrayList<Displayable> renderList;

    public RenderEngine() {
        this.renderList = new ArrayList<Displayable>();
    }

    public void setRenderList(ArrayList<Displayable> renderList) {
        this.renderList = renderList;
    }

    public void addToRenderList(Displayable displayable){
        this.renderList.add(displayable);
    }

    @Override
    public void update() {
        //System.out.println("update done");
        this.repaint();
    }

    @Override
    public void paint(Graphics g){
        super.paint(g);
        for (Displayable d:this.renderList){
            d.draw(g);
        }
    }
}
