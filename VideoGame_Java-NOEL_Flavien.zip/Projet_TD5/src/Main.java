import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class Main {
    public static JLabel texteScore;
    public static JLabel texteScoreSimple;

    public static void main(String[] args) throws IOException {
        new Main();
    }

    JFrame ecran;
    RenderEngine renderEngine;
    PhysicEngine physicEngine;
    GameEngine gameEngine;
    JPanel jPanel; //c'est comme une television virtuelle
    CardLayout cardLayout; //c'est comme la télécommande pour la TV

    public Main() throws IOException {
        //on initialise la fenêtre (la "TV")
        ecran = new JFrame();
        ecran.setSize(845,805);
        ecran.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //on "créer" la télévision et on dit qu'on peux la commander avec la télécommande cardLayout
        cardLayout = new CardLayout();
        jPanel = new JPanel(cardLayout);



        renderEngine = new RenderEngine();
        physicEngine = new PhysicEngine();


        //création de la map
        Playground playground;
        playground = new Playground("./data/level1.txt");

        for (Displayable d : playground.getSpriteList()) {
            renderEngine.addToRenderList(d);
        }

        //création de la cible
        Image targetImage = ImageIO.read(new File("./img/target.png"));
        Target target = new Target(targetImage, 400, 400, 50, 50);

        renderEngine.addToRenderList(target);

        //création du héros
        Heros heros = new Heros(ImageIO.read(new File("./img/heroTileSheetLowRes.png")),
                100, 300, 48, 50);

        renderEngine.addToRenderList(heros);
        physicEngine.addToMovingSpriteList(heros);

        //configuration des éléments des éléments solides
        ArrayList<Sprite> environment = playground.getSolidSpriteList();
        environment.add(target);
        environment.add(heros);
        physicEngine.setEnvironment(environment);



        //fenêtre de jeu
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(845, 805));
        renderEngine.setBounds(0, 0, 845, 805);
        layeredPane.add(renderEngine, JLayeredPane.DEFAULT_LAYER);

        Health health = new Health();
        health.setBounds(0, 0, 150, 50);
        layeredPane.add(health, JLayeredPane.PALETTE_LAYER);

        jPanel.add(layeredPane, "JEU");



        //fenêtre de game over GIF
        JPanel gameOverPanel = new JPanel();
        gameOverPanel.setLayout(new BorderLayout());
        gameOverPanel.setBackground(Color.BLACK);

        ImageIcon gifIcon = new ImageIcon("./img/gameover.gif");
        JLabel gif = new JLabel(gifIcon);
        gif.setHorizontalAlignment(JLabel.CENTER);
        gameOverPanel.add(gif, BorderLayout.CENTER);

        texteScore = new JLabel("Score final : 0", SwingConstants.CENTER); // Centré
        texteScore.setForeground(Color.WHITE);
        texteScore.setFont(new Font("Arial", Font.BOLD, 40));
        texteScore.setBorder(BorderFactory.createEmptyBorder(0, 0, 75, 0));
        gameOverPanel.add(texteScore, BorderLayout.SOUTH);

        jPanel.add(gameOverPanel, "GAMEOVER_GIF");



        //fenêtre de game over simple
        JPanel gameOverPanelImage = new JPanel();
        gameOverPanelImage.setLayout(new BorderLayout());
        gameOverPanelImage.setBackground(Color.BLACK);

        ImageIcon basicIcon = new ImageIcon("./img/gameover2.png");
        JLabel no_gif = new JLabel(basicIcon);
        no_gif.setHorizontalAlignment(JLabel.CENTER);
        gameOverPanelImage.add(no_gif, BorderLayout.CENTER);

        texteScoreSimple = new JLabel("Score final : 0", SwingConstants.CENTER);
        texteScoreSimple.setForeground(Color.WHITE);
        texteScoreSimple.setFont(new Font("Arial", Font.BOLD, 40));
        texteScoreSimple.setBorder(BorderFactory.createEmptyBorder(0, 0, 200, 0));
        gameOverPanelImage.add(texteScoreSimple, BorderLayout.SOUTH);

        jPanel.add(gameOverPanelImage, "GAMEOVER_SIMPLE");



        ecran.getContentPane().add(jPanel);



        //lancement musique
        Music music = new Music();
        music.playBackgroundMusic("./music/music.wav");

        gameEngine = new GameEngine(heros, renderEngine, physicEngine, cardLayout, jPanel, music, health);
        ecran.addKeyListener(gameEngine);



        Timer renderTimer = new Timer(10,(time)-> renderEngine.update());
        renderTimer.start();
        Timer physicTimer = new Timer(10,(time)-> physicEngine.update());
        physicTimer.start();
        Timer gameTimer = new Timer(10,(time)-> gameEngine.update());
        gameTimer.start();



        //début du jeu
        cardLayout.show(jPanel, "JEU");
        ecran.setVisible(true);
    }
}
