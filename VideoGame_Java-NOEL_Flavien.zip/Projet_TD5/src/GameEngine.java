import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;

public class GameEngine implements Engine, KeyListener {
    private final Heros heros;
    private final RenderEngine renderEngine;
    private final PhysicEngine physicEngine;
    private final Image arrowImage;
    private final Image arrowImage2;

    private final CardLayout cardLayout;
    private final JPanel jPanel;
    private final Music music;
    private final Health health;
    private boolean isGameOver = false;

    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean leftPressed = false;
    private boolean rightPressed = false;

    private int frameCounter =0;
    private int totalFrames = 0; //augmente la vitesse d'apparition des fleches toutes les 3 flèches

    public GameEngine(Heros hero, RenderEngine renderEngine, PhysicEngine physicEngine, CardLayout cardLayout, JPanel onglets, Music music, Health health) throws IOException {
        this.heros = hero;
        this.renderEngine = renderEngine;
        this.physicEngine = physicEngine;
        this.cardLayout = cardLayout;
        this.jPanel = onglets;
        this.music = music;
        this.health = health;
        this.arrowImage = ImageIO.read(new File("./img/arrow.png"));
        this.arrowImage2 = ImageIO.read(new File("./img/arrow2.png"));
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()){
            case KeyEvent.VK_UP -> {
                heros.setDirection(Direction.NORTH);
                upPressed = true;
                heros.setWalking(true);
            }
            case KeyEvent.VK_DOWN -> {
                heros.setDirection(Direction.SOUTH);
                downPressed = true;
                heros.setWalking(true);
            }
            case KeyEvent.VK_RIGHT -> {
                heros.setDirection(Direction.EAST);
                rightPressed = true;
                heros.setWalking(true);
            }
            case KeyEvent.VK_LEFT -> {
                heros.setDirection(Direction.WEST);
                leftPressed = true;
                heros.setWalking(true);
            }
            case KeyEvent.VK_SPACE -> {
                Arrow arrow = new Arrow(arrowImage, heros.x+4, heros.y+19, 40, 12, heros.getDirection(), true, heros);
                renderEngine.addToRenderList(arrow);
                physicEngine.addToMovingSpriteList(arrow);
            }
        }
    }

    private void spawnEnemyArrow() {
        int edge = (int) (Math.random() * 4);

        double startX = 0;
        double startY = 0;
        Direction direction = Direction.SOUTH;

        double minBound = 64;
        double maxBound_h = 677;
        double maxBound_v = 717;

        switch (edge) {
            case 0 -> { // Nord vers Sud
                startX = minBound + (Math.random() * (maxBound_v - minBound));
                startY = 64;
                direction = Direction.SOUTH;
            }
            case 1 -> { // Sud vers Nors
                startX = minBound + (Math.random() * (maxBound_v - minBound));
                startY = 690;
                direction = Direction.NORTH;
            }
            case 2 -> { // Ouest vers Est
                startX = 64;
                startY = minBound + (Math.random() * (maxBound_h - minBound));
                direction = Direction.EAST;
            }
            case 3 -> { // Est vers Ouest
                startX = 720;
                startY = minBound + (Math.random() * (maxBound_h - minBound));
                direction = Direction.WEST;
            }
        }

        Arrow enemyArrow = new Arrow(arrowImage2, startX, startY, 45, 15, direction, false, null);

        renderEngine.addToRenderList(enemyArrow);
        physicEngine.addToMovingSpriteList(enemyArrow);
    }

    @Override
    //fonction à compléter pour changer vitesse apparition des flèches en fonction de la musique
    public void update() {
        if(isGameOver){
            return;
        }

        if (this.health != null) {
            this.health.updateHealth(heros.getLives());
        }

        if (heros.isDead()) {
            isGameOver = true;

            if (cardLayout != null && jPanel != null) {
                if(heros.getScore()<10){
                    Main.texteScore.setText("<html><div style='text-align: center;'>Seulement " + heros.getScore() +" cibles ?<br>T'as joué avec tes pieds ou t'es juste mauvais ?");
                    cardLayout.show(jPanel, "GAMEOVER_GIF");

                    if (music != null) {
                        music.stopMusic();
                    }

                    Timer delayTimer = new Timer(500, (time) -> {
                        if (music != null) {
                            music.playSound("./music/laugh.wav");
                        }
                    });
                    delayTimer.setRepeats(false);
                    delayTimer.start();
                }

                else{
                    Main.texteScoreSimple.setText("Score final : " + heros.getScore());
                    cardLayout.show(jPanel, "GAMEOVER_SIMPLE");
                }
            }
        }

        double spawnInterval;
        frameCounter++;
        totalFrames++;
        int seconds = totalFrames / 100;

        if (seconds >= 73) {
            spawnInterval = 70;
        }
        else if (seconds >= 70) {
            spawnInterval = 20;
        }
        else if (seconds >= 27) {
            spawnInterval = 50;
        }
        else if (seconds >= 13) {
            spawnInterval = 15;
        }
        else if (seconds >= 7) {
            spawnInterval = 80;
        }
        else {
            spawnInterval = 150;
        }

        if (frameCounter >= spawnInterval) {
            frameCounter = 0;
            spawnEnemyArrow();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> upPressed = false;
            case KeyEvent.VK_DOWN -> downPressed = false;
            case KeyEvent.VK_LEFT -> leftPressed = false;
            case KeyEvent.VK_RIGHT -> rightPressed = false;
        }

        if (!upPressed && !downPressed && !leftPressed && !rightPressed) {
            heros.setWalking(false);
        }
    }
}