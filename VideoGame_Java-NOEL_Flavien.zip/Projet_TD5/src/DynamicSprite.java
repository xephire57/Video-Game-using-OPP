import java.awt.*;
import java.util.ArrayList;

public abstract class DynamicSprite extends SolidSprite {
    protected double speed;
    protected final int spriteSheetNumberOfColumn = 10;
    protected int timeBetweenFrame = 150;
    protected Direction direction;

    public DynamicSprite(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Direction getDirection() {
        return direction;
    }

    protected void move(){
        switch (this.direction){
            case NORTH -> this.y-=this.speed;
            case SOUTH -> this.y+=this.speed;
            case EAST -> this.x+=this.speed;
            case WEST -> this.x-=this.speed;
        }
    }

    protected abstract boolean isMovingPossible(ArrayList<Sprite> environment);

    public abstract void moveIfPossible(ArrayList<Sprite> environment);
}
