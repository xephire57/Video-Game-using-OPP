import java.awt.*;

public class SolidSprite extends Sprite{
    public SolidSprite(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
    }

    public boolean isTarget() {
        return false;
    }

    public boolean isHeros() {
        return false;
    }

    @Override
    public boolean isSolidSprite() {
        return true;
    }
}
