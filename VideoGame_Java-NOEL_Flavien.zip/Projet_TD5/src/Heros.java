import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Heros extends DynamicSprite {
    protected boolean isWalking = false;
    private int lives;
    private int score;

    public Heros(Image image, double x, double y, double width, double height) {
        super(image, x, y, width, height);
        this.setDirection(Direction.SOUTH);
        this.speed = 2;
        this.lives = 3;
        this.score = 0;
    }

    @Override
    protected boolean isMovingPossible(ArrayList<Sprite> environment) {
        Rectangle2D.Double hitBox = new Rectangle2D.Double(this.x, this.y, this.width, this.height);
        switch (this.direction){
            case NORTH -> hitBox.y-=this.speed;
            case SOUTH -> hitBox.y+=this.speed;
            case EAST -> hitBox.x+=this.speed;
            case WEST -> hitBox.x-=this.speed;
        }

        for (Sprite s : environment){
            if((s.isSolidSprite())&&(s!=this)){
                Rectangle2D.Double obstacle = new Rectangle2D.Double(s.x, s.y, s.width, s.height);
                if (hitBox.intersects(obstacle)){
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void moveIfPossible(ArrayList<Sprite> environment) {
        if((this.isMovingPossible(environment))&&(this.isWalking)){
            this.move();
        }
    }

    public void setWalking(boolean walking) {
        this.isWalking = walking;
    }

    public int getLives() {
        return this.lives;
    }

    public void takeDamage() {
        this.lives--;
    }

    public boolean isDead() {
        return this.lives <= 0;
    }

    public int getScore() {
        return score;
    }

    public void addScore(int points) {
        this.score += points;
    }

    @Override
    public void draw(Graphics g) {
        int index = 0;
        if(this.isWalking){
            index =((int)System.currentTimeMillis()/this.timeBetweenFrame)%this.spriteSheetNumberOfColumn;
        }
        int attitude = this.direction.getFrameLineNumber();
        g.drawImage(this.image,(int)this.x,(int)this.y,(int)this.width+(int)this.x,(int)this.height+(int)this.y,(int)this.width*index,(int)this.height*attitude,(int)this.width*(index+1),(int)this.height*(attitude+1),null);
    }

    @Override
    public boolean isHeros() {
        return true;
    }
}