import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Arrow extends DynamicSprite {
    private final boolean friendly; // pour savoir si la flèche est tiré par le héros ou non
    private boolean isMoving;
    private final Heros heros;

    public Arrow(Image image, double x, double y, double width, double height, Direction direction, boolean friendly, Heros heros) {
        super(image, x, y, width, height);
        this.setDirection(direction);
        this.friendly = friendly;
        this.isMoving = true;
        this.speed = 4;
        this.heros = heros;
    }

    public void fly(ArrayList<Sprite> environment) {
        if (this.isMoving) {
            if (this.isMovingPossible(environment)) {
                this.move();
            }
            else {
                this.isMoving = false;
            }
        }
    }

    @Override
    protected boolean isMovingPossible(ArrayList<Sprite> environment){
        Rectangle2D.Double hitBox = new Rectangle2D.Double(this.x, this.y, this.width, this.height);
        switch (this.direction){
            case NORTH -> hitBox.y-=this.speed;
            case SOUTH -> hitBox.y+=this.speed;
            case EAST -> hitBox.x+=this.speed;
            case WEST -> hitBox.x-=this.speed;
        }

        for (Sprite s : environment){
            if((s.isSolidSprite())&&(s!=this)){
                Rectangle2D.Double obstacle = new Rectangle2D.Double(s.x, s.y, s.width, s.height);
                if (hitBox.intersects(obstacle)){
                    if (s instanceof Target target) {
                        if (this.friendly && this.heros != null) {
                            heros.addScore(1);
                            target.respawn(environment);
                        }
                    }

                    else if (s instanceof Heros hero) {
                        if (!this.friendly) {
                            hero.takeDamage();
                        }
                        else {
                            return true;
                        }
                    }

                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void moveIfPossible(ArrayList<Sprite> environment) {
        this.fly(environment);
    }

     @Override
    public void draw(Graphics g) {
        if (this.isMoving) {
            Graphics2D arrow = (Graphics2D) g.create();

            double angle = 0;
            switch (this.getDirection()) {
                case EAST -> angle = 0;
                case SOUTH -> angle = Math.PI / 2;
                case WEST -> angle = Math.PI;
                case NORTH -> angle = -Math.PI / 2;
            }
            arrow.rotate(angle, this.x + (this.width / 2), this.y + (this.height / 2));
            arrow.drawImage(this.image, (int)this.x, (int)this.y, (int)this.width, (int)this.height, null);
            arrow.dispose();
        }
    }
}

